import fetch from "node-fetch"

async function checaStatus(arrayURl){
    const arrayStatus = await Promise.all(arrayURl.map(async url => {
        const res = await fetch(url)
        return res.status
    }))

    return arrayStatus
}


function geraArrayDeURL(arrayLinks){
    return arrayLinks.map(objetolink => Object.values(objetolink).join())
}

async function validaURL(arrayLinks){
    const links = geraArrayDeURL(arrayLinks)
    const statusLinks = await checaStatus(links)
    return statusLinks
}



export default validaURL